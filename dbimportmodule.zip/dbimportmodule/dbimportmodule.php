<?php
//require_once(dirname(__FILE__).'/cronjob.php');

if (!defined('_PS_VERSION_')) {
	exit;
}


class DbImportModule extends Module
{

	protected $render_Form = false;

	public function __construct()
	{
		$this->name = 'dbimportmodule';
		$this->tab = 'administration';
		$this->version = '1.0.0';
		$this->author = 'Mindaugas Andriusaitis';
		$this->need_instance = 0;
		$this->ps_versions_compliancy = array('min' => '1.6', 'max' => _PS_VERSION_);
		/**
		 * Set $this->bootstrap to true if your module is compliant with bootstrap (PrestaShop 1.6)
		 */
		$this->bootstrap = true;

		parent::__construct();
		$this->confirmUninstall = $this->l('');
		$this->displayName = $this->l('Database Import Module');
		$this->description = $this->l('This module imports data from a database server into PrestaShop.');
	}

	/**
	 * Don't forget to create update methods if needed:
	 * http://doc.prestashop.com/display/PS16/Enabling+the+Auto-Update
	 */
	public function install()
	{
		include(dirname(__FILE__) . '/sql/install.php');

		return parent::install();
	}

	public function uninstall()
	{

		include(dirname(__FILE__) . '/sql/uninstall.php');

		return parent::uninstall();
	}


	/**
	 * Load the configuration form
	 */
	public function getContent()
	{
		$output = null;


		if (Tools::isSubmit('submitDbImport')) {

			Configuration::updateValue('DBIMPORTMODULE_SERVER', Tools::getValue('DBIMPORTMODULE_SERVER'));
			Configuration::updateValue('DBIMPORTMODULE_USERNAME', Tools::getValue('DBIMPORTMODULE_USERNAME'));
			Configuration::updateValue('DBIMPORTMODULE_PASSWORD', Tools::getValue('DBIMPORTMODULE_PASSWORD'));
			Configuration::updateValue('DBIMPORTMODULE_DATABASE', Tools::getValue('DBIMPORTMODULE_DATABASE'));
			Configuration::updateValue('FEATURE_', Tools::getValue('FEATURE_'));
			Configuration::updateValue('MANUFACTURER_', Tools::getValue('MANUFACTURER_'));
			Configuration::updateValue('CATEGORY_', Tools::getValue('CATEGORY_'));
			Configuration::updateValue('CURRENCY_CODE', Tools::getValue('CURRENCY_CODE'));
			Configuration::updateValue('LANGUAGE_CODE', Tools::getValue('LANGUAGE_CODE'));

			$categories = Db::getInstance()->executeS('SELECT title, id FROM `ps_import_category`');
			//dump(Tools::getValue('CATEGORY_61'));
			foreach ($categories as $category) {
				Configuration::updateValue('CATEGORY_' . (int)$category['id'], Tools::getValue('CATEGORY_' . (int)$category['id']));
			}

			$manufacturers = Db::getInstance()->executeS('SELECT title, id FROM `ps_import_manufacturer`');
			foreach ($manufacturers as $manufacturer) {
				Configuration::updateValue('MANUFACTURER_' . (int)$manufacturer['id'], Tools::getValue('MANUFACTURER_' . (int)$manufacturer['id']));
			}

			$importFeatures = Db::getInstance()->executeS('SELECT title, id FROM `ps_import_feature`');
			foreach ($importFeatures as $importFeature) {
				Configuration::updateValue('FEATURE_' . (int)$importFeature['id'], Tools::getValue('FEATURE_' . (int)$importFeature['id']));
			}
//			cronjob();
		}


		return $output . $this->renderForm();
	}

	/**
	 * Create the structure of your form.
	 */
	protected function renderForm()
	{
		$fields_form = array(
			'form' => array(
				'tabs' => array(
					'Dbimport' => $this->l("Nustatymai"),
					'Valiutos' => $this->l("Valiutos"),
					'Kalbos' => $this->l("Kalbos"),
					'Kategorijos' => $this->l("Kategorijos"),
					'Gamintojai' => $this->l("Gamintojai"),
					'Ypatybes' => $this->l("Ypatybes"),
				),
				'legend' => array(
					'title' => $this->l('Prekių importavimas')
				),
				'input' => array(
					array(
						'col' => 3,
						'tab' => 'Dbimport',
						'type' => 'text',
						'label' => $this->l('Prekių nuoroda:'),
						'name' => 'DBIMPORTMODULE_SERVER',
						'class' => 'form-group right-column',
					),
					array(
						'col' => 3,
						'tab' => 'Dbimport',
						'type' => 'text',
						'label' => $this->l('Prisijungimo vardas:'),
						'name' => 'DBIMPORTMODULE_USERNAME',
					),
					array(
						'col' => 3,
						'tab' => 'Dbimport',
						'type' => 'text',
						'label' => $this->l('Prisijungimo slaptažodis:'),
						'name' => 'DBIMPORTMODULE_PASSWORD',
					),
					array(
						'col' => 3,
						'tab' => 'Dbimport',
						'type' => 'text',
						'label' => $this->l('Tiekėjo kodas:'),
						'name' => 'DBIMPORTMODULE_DATABASE',
					),
				),
			),
		);

		error_reporting(E_ALL & ~E_NOTICE);
		$importFeatures = Db::getInstance()->executeS('SELECT title, id FROM `ps_import_feature`');
		foreach ($importFeatures as $importFeature) {
			$selectedOption = Db::getInstance()->getValue('SELECT feature_id FROM `ps_import_feature` WHERE `id` = \'' . pSQL($importFeature['id']) . '\'');
			$options = array();
			foreach (Feature::getFeatures($this->context->language->id) as $feature) {
				$options[] = array(
					'id' => $feature['id_feature'],
					'name' => $feature['name'],
					'selected' => $selectedOption,
				);
			}

			$fields_form['form']['submit'] = array(
				'title' => $this->l('Išsaugoti'),
				'name' => 'submitAndExit',
			);

			$fields_form['form']['input'][] = array(
				'col' => 3,
				'tab' => 'Ypatybes',
				'type' => 'select',
				'label' => $importFeature['title'],
				'name' => 'FEATURE_' . (int)$importFeature['id'],
				'options' => array(
					'query' => $options,
					'id' => 'id',
					'name' => 'name',
					'class' => 'select2',
				),
			);
		}
		if (Tools::isSubmit('submitAndExit')) {
			foreach ($importFeatures as $importFeature) {
				$identifierFieldName = 'FEATURE_' . $importFeature['id'];
				if (!empty($_POST[$identifierFieldName])) {
					$features = (int)$_POST[$identifierFieldName]; // nurodome, kad reikšmė yra skaičius
					$importFeatureIdentifier = pSQL($importFeature['id']);
					Db::getInstance()->update('import_feature', array('feature_id' => $features), '`id` = \'' . $importFeatureIdentifier . '\'');
				}
			}
		}
		$manufacturers = Db::getInstance()->executeS('SELECT title, id FROM `ps_import_manufacturer` ORDER BY title ASC');
		foreach ($manufacturers as $manufacturer) {
			$selectedOption = Db::getInstance()->getValue('SELECT manufacturer_id FROM `ps_import_manufacturer` WHERE `id` = \'' . pSQL($manufacturer['id']) . '\'');
			$options = array();
			foreach (Manufacturer::getManufacturers($this->context->language->id) as $manufacturerOption) {
				$options[] = array(
					'id' => $manufacturerOption['id_manufacturer'],
					'name' => $manufacturerOption['name'],
					'selected' => $selectedOption
				);
			}
			$fields_form['form']['input'][] = array(
				'col' => 3,
				'tab' => 'Gamintojai',
				'type' => 'select',
				'label' => $manufacturer['title'],
				'name' => 'MANUFACTURER_' . $manufacturer['id'],
				'options' => array(
					'query' => $options,
					'id' => 'id',
					'name' => 'name',
					'class' => 'select2',
				),
			);
		}

		if (Tools::isSubmit('submitAndExit')) {
			foreach ($manufacturers as $manufacturer) {
				$identifierFieldName = 'MANUFACTURER_' . $manufacturer['id'];
				if (!empty($_POST[$identifierFieldName])) {
					$manufacturerId = $_POST[$identifierFieldName];
					$importManufacturerId = pSQL($manufacturer['id']);
					Db::getInstance()->update('import_manufacturer', array('manufacturer_id' => $manufacturerId), '`id` = \'' . pSQL($importManufacturerId) . '\'');
				}
			}
		}
		$root_category =  new Category(Category::getRootCategory()->id);
		$category_paths = $root_category->getNestedCategories();
//print_r($category_paths);
//exit();
		$category_names = array();
		print_category_tree($category_paths,0,"", $category_names);
		//print_r($category_names);
		//exit();

		$categories = Db::getInstance()->executeS('SELECT title, id FROM `ps_import_category` ORDER BY title ASC');
		foreach ($categories as $category) {
			$options = array();
			foreach ($category_names as $categoryOption) {

				$categoryId = getCategoryIdByName($categoryOption);
				//dump($categoryId[0]['id_category']);
				$options[] = array(
					'id' => $categoryId[0]['id_category'],
					'name' => $categoryOption,
				);
			}
			$fields_form['form']['input'][] = array(
				'col' => 3,
				'tab' => 'Kategorijos',
				'type' => 'select',
				'label' => $category['title'],
				'name' => 'CATEGORY_' . (int)$category['id'],
				'options' => array(
					'query' => $options,
					'id' => 'id',
					'name' => 'name',
					'class' => 'select2',
				),
			);
		}
		if (Tools::isSubmit('submitAndExit')) {
			foreach ($categories as $category) {
				$identifierFieldName = 'CATEGORY_' . $category['id'];
				if (!empty($_POST[$identifierFieldName])) {
					$categoryId = (int)$_POST[$identifierFieldName];
					$importCategoryId = pSQL($category['id']);
					Db::getInstance()->update('import_category', array('category_id' => $categoryId), '`id` = \'' . $importCategoryId . '\'');
				}
			}
		}
		$currencies = Currency::getCurrencies();
		$options = array();
		foreach ($currencies as $currency) {
			$options[] = array(
				'id' => $currency['iso_code'],
				'name' => $currency['name'],
			);
		}
		$fields_form['form']['input'][] = array(
			'col' => 3,
			'tab' => 'Valiutos',
			'type' => 'select',
			'label' => $this->l('Valiuta'),
			'name' => 'CURRENCY_CODE',
			'options' => array(
				'query' => $options,
				'id' => 'id',
				'name' => 'name',

			),
		);

		$languages = Language::getLanguages();
		$options = array();
		foreach ($languages as $language) {
			$options[] = array(
				'id' => $language['iso_code'],
				'name' => $language['name'],
			);
		}

		$fields_form['form']['input'][] = array(
			'col' => 3,
			'tab' => 'Kalbos',
			'type' => 'select',
			'label' => $this->l('Kalba'),
			'name' => 'LANGUAGE_CODE',
			'options' => array(
				'query' => $options,
				'id' => 'id',
				'name' => 'name',

			),
		);
		$this->context->controller->addJS($this->_path . '/views/js/back.js');
//		$this->context->controller->addJqueryPlugin('select2');

		/**
		 * Create the form that will be displayed in the configuration of your module.
		 */
		$helper = new HelperForm();

		$helper->show_toolbar = false;
		$helper->table = $this->table;
		$helper->module = $this;
		$helper->default_form_language = $this->context->language->id;
		$helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG', 0);
		$helper->identifier = $this->identifier;
		$helper->submit_action = 'submitDbImport';
		$helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false)
			. '&configure=' . $this->name . '&tab_module=' . $this->tab . '&module_name=' . $this->name;
		$helper->token = Tools::getAdminTokenLite('AdminModules');
		$helper->tpl_vars = array(
			'fields_value' => $this->getConfigFormValues(),
			'languages' => $this->context->controller->getLanguages(),
			'id_language' => $this->context->language->id,
		);

		return $helper->generateForm(array($fields_form));
	}

	/**
	 * Set values for the inputs.
	 */
	protected function getConfigFormValues()
	{
		$tempArray = array(
			'CURRENCY_CODE' => Tools::getValue('CURRENCY_CODE', Configuration::get('CURRENCY_CODE')),
			'FEATURE_' => Tools::getValue('FEATURE_', Configuration::get('FEATURE_')),
			'MANUFACTURER_' => Tools::getValue('MANUFACTURER_', Configuration::get('MANUFACTURER_')),
			'LANGUAGE_CODE' => Tools::getValue('LANGUAGE_CODE', Configuration::get('LANGUAGE_CODE')),
			'CATEGORY_' => Tools::getValue('CATEGORY_', Configuration::get('CATEGORY_')),
			'DBIMPORTMODULE_SERVER' => Tools::getValue('DBIMPORTMODULE_SERVER', Configuration::get('DBIMPORTMODULE_SERVER')),
			'DBIMPORTMODULE_USERNAME' => Tools::getValue('DBIMPORTMODULE_USERNAME', Configuration::get('DBIMPORTMODULE_USERNAME')),
			'DBIMPORTMODULE_PASSWORD' => Tools::getValue('DBIMPORTMODULE_PASSWORD', Configuration::get('DBIMPORTMODULE_PASSWORD')),
			'DBIMPORTMODULE_DATABASE' => Tools::getValue('DBIMPORTMODULE_DATABASE', Configuration::get('DBIMPORTMODULE_DATABASE')),

		);
		$categories = Db::getInstance()->executeS('SELECT title, id FROM `ps_import_category`');
		foreach ($categories as $category) {
			$tempArray['CATEGORY_' . (int)$category['id']] = Configuration::get('CATEGORY_' . (int)$category['id']);
		}

		$manufacturers = Db::getInstance()->executeS('SELECT title, id FROM `ps_import_manufacturer`');
		foreach ($manufacturers as $manufacturer) {
			$tempArray['MANUFACTURER_' . (int)$manufacturer['id']] = Tools::getValue('MANUFACTURER_' . (int)$manufacturer['id'], Configuration::get('MANUFACTURER_' . (int)$manufacturer['id']));
		}

		$importFeatures = Db::getInstance()->executeS('SELECT title, id FROM `ps_import_feature`');

		foreach ($importFeatures as $importFeature) {
			$tempArray['FEATURE_' . (int)$importFeature['id']] = Tools::getValue('FEATURE_' . (int)$importFeature['id'], Configuration::get('FEATURE_' . (int)$importFeature['id']));

		}
		return $tempArray;
	}
}
function getCategoryIdByName($categoryOption)
{
	$categories = explode('->', $categoryOption);
	$lastCategory = end($categories);

	$Db = Db::getInstance();
	$query = new DbQuery();
	$query->select('id_category');
	$query->from('category_lang');
	$query->where('name = \'' . $lastCategory . '\'');
	$query->where('id_lang = 1');
	$result = $Db->executeS($query);

	return $result;
}
function print_category_tree($categories, $level = 0, $name, &$category_names){
	foreach ($categories as $category){
		if( $level == 0)
		{
			$newName = $category['name'];
		}
		else
		{
			$newName = "{$name}->{$category['name']}";
		}
		array_push($category_names, $newName);
		//echo $newName . "\n";
		print_category_tree($category['children'], $level + 1, $newName, $category_names);
	}
}