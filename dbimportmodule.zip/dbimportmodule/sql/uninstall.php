<?php
!Db::getInstance()->Execute('DROP TABLE IF EXISTS `'._DB_PREFIX_.'import_feature`');
!Db::getInstance()->Execute('DROP TABLE IF EXISTS `'._DB_PREFIX_.'import_manufacturer`');
!Db::getInstance()->Execute('DROP TABLE IF EXISTS `'._DB_PREFIX_.'import_category`');